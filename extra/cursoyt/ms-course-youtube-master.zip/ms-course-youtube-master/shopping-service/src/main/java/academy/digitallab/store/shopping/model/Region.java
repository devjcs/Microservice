package academy.digitallab.store.shopping.model;

import lombok.Data;

@Data
public class Region {
    private Long id;
    private String name;
}
